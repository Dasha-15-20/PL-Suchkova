import requests
import json
from pprint import pprint

username = "Firehol"
url = f"https://api.github.com/users/{username}"
user_data_ = requests.get(url).json()

print(user_data_)
print('-'*25)
s1 = json.dumps(user_data_)
user_data = json.loads(s1)
info = {
        'company'   : (user_data["company"]   ),
        'created_at': (user_data["created_at"]),
        'email'     : (user_data["email"]     ),
        'id'        : (user_data["id"]        ),
        'name'      : (user_data["name"]      ),
        'url'       : (user_data["url"]       )
        }
pprint(info)

with open('Задание 11.txt', 'w') as file_json:
  json.dump(info,file_json)